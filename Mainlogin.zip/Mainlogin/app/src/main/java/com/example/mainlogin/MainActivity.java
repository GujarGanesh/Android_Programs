package com.example.mainlogin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText username,password;
    private Button btn;
    private String UserName="admin";
    private String Password="password123";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        btn=findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String USERNAME=username.getText().toString().trim();
                String PASSWORD=password.getText().toString().trim();
                if (USERNAME.equals(UserName) && PASSWORD.equals(Password)){
                    Toast.makeText(MainActivity.this, "Login Succefull", Toast.LENGTH_SHORT).show();
                } else{
                    Toast.makeText(MainActivity.this, "UserName and Password don not avialable", Toast.LENGTH_SHORT).show();
                }
                username.setText("");
                password.setText("");
            }
        });
    }
}