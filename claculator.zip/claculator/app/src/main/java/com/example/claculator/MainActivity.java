package com.example.claculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText num1,num2;
    private Button add,sub,mult,div;
    private TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1=findViewById(R.id.num1);
        num2=findViewById(R.id.num2);
        add=findViewById(R.id.add);
        sub=findViewById(R.id.sub);
        mult=findViewById(R.id.mult);
        div=findViewById(R.id.div);
        result=findViewById(R.id.result);


        double Re=0;
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Num1=num1.getText().toString().trim();
                String Num2=num2.getText().toString().trim();
                double n1 = Double.parseDouble(Num1);
                double n2 = Double.parseDouble(Num2);
                double Re=n1+n2;
                result.setText("Result  :" + Re);

            }
        });
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Num1=num1.getText().toString().trim();
                String Num2=num2.getText().toString().trim();
                double n1 = Double.parseDouble(Num1);
                double n2 = Double.parseDouble(Num2);
                double Re=n1-n2;
                result.setText("Result  :" + Re);

            }
        });
        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Num1=num1.getText().toString().trim();
                String Num2=num2.getText().toString().trim();
                double n1 = Double.parseDouble(Num1);
                double n2 = Double.parseDouble(Num2);
                double Re=n1*n2;
                result.setText("Result  :" + Re);

            }
        });
        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Num1=num1.getText().toString().trim();
                String Num2=num2.getText().toString().trim();
                double n1 = Double.parseDouble(Num1);
                double n2 = Double.parseDouble(Num2);
                if(n1==0||n2==0){
                    Toast.makeText(MainActivity.this, "not divisiable by zero", Toast.LENGTH_SHORT).show();
                }else {

                    double Re = n1 / n2;
                    result.setText("Result  :" + Re);
                }


            }
        });

    }
}