package com.example.login;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText username,email,password,confirmpassword;
    private Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=findViewById(R.id.username);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        confirmpassword=findViewById(R.id.comfirmpassword);
        btn=findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Name=username.getText().toString().trim();
                String Email=email.getText().toString().trim();
                String Password=password.getText().toString().trim();
                String Confirmpassword=confirmpassword.getText().toString().trim();

                if(Name.isEmpty()|| Email.isEmpty() || Password.isEmpty()|| Confirmpassword.isEmpty()){

                    Toast.makeText(MainActivity.this,"Please all the fileds",Toast.LENGTH_SHORT).show();
                } else if (!Password.equals(Confirmpassword)) {
                    Toast.makeText(MainActivity.this,"Password do not match",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,"Login Succesfully",Toast.LENGTH_SHORT).show();
                }

                username.setText("");
                email.setText("");
                password.setText("");
                confirmpassword.setText("");

            }
        });
    }
}